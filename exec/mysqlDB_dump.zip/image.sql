create table image
(
    image_id             int auto_increment
        primary key,
    image_reference_id   int               not null,
    is_delete            tinyint default 0 not null,
    created_at           datetime(6)       not null,
    deleted_at           datetime(6)       null,
    modified_at          datetime(6)       not null,
    image_reference_type char              not null,
    image_url            varchar(255)      not null,
    is_deleted           tinyint default 0 not null
);

INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (1, 24, 0, '2024-05-12 19:45:21.438829', null, '2024-05-12 19:45:21.438829', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715510719959_image%3A1000000020', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (2, 25, 0, '2024-05-12 23:06:21.706970', null, '2024-05-12 23:06:21.706970', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715522779473_image%3A1000000020', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (3, 29, 0, '2024-05-13 15:31:55.818723', null, '2024-05-13 15:31:55.818723', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715581913802_image%3A1000000034', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (4, 29, 0, '2024-05-13 15:31:55.831840', null, '2024-05-13 15:31:55.831840', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715581915300_image%3A1000000033', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (5, 30, 0, '2024-05-16 09:45:05.059422', null, '2024-05-16 09:45:05.059422', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715820303011_image%3A1000000033', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (6, 30, 0, '2024-05-16 09:45:05.092085', null, '2024-05-16 09:45:05.092085', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715820304649_image%3A1000000034', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (7, 32, 0, '2024-05-16 16:28:19.723993', null, '2024-05-16 16:28:19.723993', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1715844498081_image%3A1000000034', 0);
INSERT INTO common.image (image_id, image_reference_id, is_delete, created_at, deleted_at, modified_at, image_reference_type, image_url, is_deleted) VALUES (8, 40, 0, '2024-05-20 06:18:25.436601', null, '2024-05-20 06:18:25.436601', 'G', 'https://ssanteutbucket.s3.ap-southeast-2.amazonaws.com/1716153503796_image%3A9496', 0);
