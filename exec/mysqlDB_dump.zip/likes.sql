create table likes
(
    is_delete           tinyint default 0 not null,
    like_id             int auto_increment
        primary key,
    like_reference_id   int               not null,
    user_id             int               not null,
    created_at          datetime(6)       not null,
    deleted_at          datetime(6)       null,
    modified_at         datetime(6)       not null,
    like_reference_type char              not null,
    is_deleted          tinyint default 0 not null
);

INSERT INTO common.likes (is_delete, like_id, like_reference_id, user_id, created_at, deleted_at, modified_at, like_reference_type, is_deleted) VALUES (0, 35, 43, 3, '2024-05-20 09:59:54.495427', null, '2024-05-20 09:59:54.495427', 'G', 0);
INSERT INTO common.likes (is_delete, like_id, like_reference_id, user_id, created_at, deleted_at, modified_at, like_reference_type, is_deleted) VALUES (0, 36, 42, 2, '2024-05-20 10:14:08.275829', null, '2024-05-20 10:14:08.275829', 'G', 0);
INSERT INTO common.likes (is_delete, like_id, like_reference_id, user_id, created_at, deleted_at, modified_at, like_reference_type, is_deleted) VALUES (0, 37, 41, 2, '2024-05-20 10:14:20.054707', null, '2024-05-20 10:14:20.054707', 'G', 0);
INSERT INTO common.likes (is_delete, like_id, like_reference_id, user_id, created_at, deleted_at, modified_at, like_reference_type, is_deleted) VALUES (0, 38, 45, 23, '2024-05-20 10:25:23.450370', null, '2024-05-20 10:25:23.450370', 'G', 0);
