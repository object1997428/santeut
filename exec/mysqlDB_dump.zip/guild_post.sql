create table guild_post
(
    guild_post_id      int auto_increment
        primary key,
    category_id        int           not null,
    created_at         datetime(6)   not null,
    deleted_at         datetime(6)   null,
    guild_id           int           not null,
    guild_post_content text          not null,
    guild_post_title   varchar(150)  not null,
    is_deleted         bit           not null,
    modified_at        datetime(6)   not null,
    user_id            int           not null,
    hit_cnt            int default 0 not null
);

INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (39, 1, '2024-05-19 21:33:23.899955', null, 37, 'test', 'Test', false, '2024-05-19 21:33:23.899955', 19, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (40, 1, '2024-05-20 06:18:23.724139', null, 30, '~~', '즐 주말되세요', false, '2024-05-20 06:18:23.724139', 2, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (41, 1, '2024-05-20 06:26:12.147217', null, 36, '등산 모임은 처음인데 잘 부탁드립니다.', '안녕하세요 😀', false, '2024-05-20 06:26:12.147217', 2, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (42, 1, '2024-05-20 08:44:39.954484', null, 36, '승학산 같이 타지 않으실래요?', '명지/하단에 거주하시는 분', false, '2024-05-20 08:44:39.954484', 3, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (43, 0, '2024-05-20 09:48:31.828979', null, 36, '1. 회원 간 존중 부탁드립니다.
2. 소모임 참여 후 무단으로 불참 하지 마세요.', '공지사항', false, '2024-05-20 09:48:31.828979', 23, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (44, 1, '2024-05-20 09:54:25.344897', null, 36, '등산도 좋지만 건강해치지 않게 안전하게 합시다.', '갑자기 너무 더워지네요.', false, '2024-05-20 09:54:25.344897', 2, 0);
INSERT INTO guild.guild_post (guild_post_id, category_id, created_at, deleted_at, guild_id, guild_post_content, guild_post_title, is_deleted, modified_at, user_id, hit_cnt) VALUES (45, 1, '2024-05-20 09:54:26.763438', null, 36, '7시에는 하산하는 걸 추천합니다. 야간 산행은 위험해요', '여름이라 해가 길어졌어도', false, '2024-05-20 09:54:26.763438', 20, 0);
