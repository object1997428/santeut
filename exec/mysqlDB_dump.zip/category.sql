create table category
(
    category_id   int auto_increment
        primary key,
    category_name varchar(15) not null
);

INSERT INTO guild.category (category_id, category_name) VALUES (0, 'notice');
INSERT INTO guild.category (category_id, category_name) VALUES (1, 'free');
