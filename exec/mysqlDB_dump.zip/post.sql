create table post
(
    post_id       int auto_increment
        primary key,
    created_at    datetime(6)       not null,
    deleted_at    datetime(6)       null,
    is_delete     tinyint default 0 not null,
    modified_at   datetime(6)       not null,
    post_content  varchar(255)      not null,
    post_title    varchar(255)      not null,
    post_type     char              not null,
    user_id       int               not null,
    user_party_id int               not null,
    is_deleted    tinyint default 0 not null,
    hit_cnt       int               not null
);

INSERT INTO community.post (post_id, created_at, deleted_at, is_delete, modified_at, post_content, post_title, post_type, user_id, user_party_id, is_deleted, hit_cnt) VALUES (25, '2024-05-20 04:54:59.046748', null, 0, '2024-05-20 04:54:59.046748', '짐은 최소화하고 열정만 챙기시면 됩니다', '지리산 갈 때 꼭 챙겨가야 할 것', 'T', 3, 0, 0, 7);
INSERT INTO community.post (post_id, created_at, deleted_at, is_delete, modified_at, post_content, post_title, post_type, user_id, user_party_id, is_deleted, hit_cnt) VALUES (26, '2024-05-20 05:30:42.233191', null, 0, '2024-05-20 05:30:42.233191', '준비운동', '안전한 등산을 위한 팁', 'T', 23, 0, 0, 3);
INSERT INTO community.post (post_id, created_at, deleted_at, is_delete, modified_at, post_content, post_title, post_type, user_id, user_party_id, is_deleted, hit_cnt) VALUES (27, '2024-05-20 08:40:50.646917', null, 0, '2024-05-20 08:40:50.646917', '탈수 예방을 위해서 물은 꼭 챙기세요', '요즘 날이 더워서', 'T', 3, 0, 0, 0);
INSERT INTO community.post (post_id, created_at, deleted_at, is_delete, modified_at, post_content, post_title, post_type, user_id, user_party_id, is_deleted, hit_cnt) VALUES (28, '2024-05-20 09:46:06.982343', null, 0, '2024-05-20 09:46:06.982343', '이온음료 챙겨서 수분 보충하세요', '날이 더우니 주의하세요.', 'T', 20, 0, 0, 1);
INSERT INTO community.post (post_id, created_at, deleted_at, is_delete, modified_at, post_content, post_title, post_type, user_id, user_party_id, is_deleted, hit_cnt) VALUES (29, '2024-05-20 09:49:18.774708', null, 0, '2024-05-20 09:49:18.774708', '부산 승학산 이 시기에 뷰가 좋습니다', '풍경 좋은 산 추천', 'T', 2, 0, 0, 1);
