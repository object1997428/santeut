create table guild_request
(
    guild_request_id int auto_increment
        primary key,
    created_at       datetime(6) not null,
    guild_id         int         not null,
    modified_at      datetime(6) not null,
    status           char        not null,
    user_id          int         not null
);

INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (116, '2024-05-19 21:33:08.141076', 70, '2024-05-19 21:33:08.141080', 'A', 17);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (117, '2024-05-19 21:34:54.578785', 70, '2024-05-19 23:02:51.565392', 'D', 14);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (118, '2024-05-19 23:02:30.741133', 70, '2024-05-19 23:02:54.353295', 'D', 3);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (119, '2024-05-20 04:21:12.516231', 71, '2024-05-20 04:21:12.516234', 'A', 3);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (120, '2024-05-20 04:34:08.370961', 71, '2024-05-20 04:34:33.763722', 'A', 20);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (121, '2024-05-20 05:20:31.192057', 71, '2024-05-20 06:53:12.440781', 'A', 23);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (122, '2024-05-20 05:21:09.528817', 36, '2024-05-20 06:24:42.615659', 'A', 3);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (123, '2024-05-20 05:32:04.999119', 37, '2024-05-20 09:33:34.039005', 'A', 3);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (124, '2024-05-20 06:11:07.568214', 71, '2024-05-20 06:53:10.851328', 'A', 2);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (125, '2024-05-20 06:12:59.588532', 36, '2024-05-20 06:24:43.883298', 'A', 2);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (126, '2024-05-20 06:26:37.479927', 36, '2024-05-20 12:36:45.437813', 'A', 5);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (127, '2024-05-20 08:57:30.956886', 36, '2024-05-20 09:00:14.671273', 'A', 20);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (128, '2024-05-20 09:03:17.700143', 36, '2024-05-20 12:37:57.607988', 'A', 4);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (129, '2024-05-20 09:30:21.888006', 71, '2024-05-20 09:31:18.073681', 'A', 5);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (130, '2024-05-20 09:46:45.619953', 72, '2024-05-20 09:46:45.619956', 'A', 4);
INSERT INTO guild.guild_request (guild_request_id, created_at, guild_id, modified_at, status, user_id) VALUES (131, '2024-05-20 10:15:37.986943', 71, '2024-05-20 10:16:03.606254', 'D', 17);
