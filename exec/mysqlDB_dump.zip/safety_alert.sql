create table safety_alert
(
    safety_alert_id      int auto_increment
        primary key,
    created_at           datetime(6)  not null,
    safety_alert_message varchar(255) not null,
    alert_point          geometry     not null,
    safety_alert_title   varchar(255) not null,
    user_id              int          not null
);

