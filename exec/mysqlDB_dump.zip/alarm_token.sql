create table alarm_token
(
    user_id        int          not null
        primary key,
    last_active_at datetime(6)  not null,
    created_at     datetime(6)  not null,
    fcm_token      varchar(255) not null
);

INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (2, '2024-05-17 12:07:26.542834', '2024-05-17 12:07:26.542834', 'dCwKwx9wRCOXWamuWi9RGe:APA91bGJYK_3vKQzPVSssA7UjfDKV92x0JDa4DaVbUFYypx2iN63EecMvdU7sc7Gjlb4tEmsq9vGfIQ4WKZvExkM5x21tOHJixNg8jbE6Kr8LHfzzMK_NoKSF1EGT-OE-b69k6gKU5x1');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (3, '2024-05-20 03:54:32.553553', '2024-05-20 03:54:32.553553', 'cFV7-N_RRzyfPhR1sxp-li:APA91bEqBo7B6Ym13nurUIQ5o4tgfhlqh6UMG9ZuaUWbS6h-XdWSAwQRxvVTTbdTNB4zxoPCoQatRpgc_fS4rc-_c75SDiNRMaTtpTPz_5IGKlLLk6vCbT2LZYpiNPglMDcoQfHWtKTf');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (4, '2024-05-20 09:43:19.603184', '2024-05-20 09:43:19.603184', 'fu0ij5taTredvb3hTiJuHu:APA91bEXwwQRq8rlahfY6iqqhp2GsQbFPRkQZVuJTvOthRVC0msCDoj3I8cAQSy1lHgfffTsdm-DsdKW5mZ-xDrVNl0QHWHC_aZAvEKcq5G9Y0z5Zjccz1KgvJrFVsZIvzTMK0mhlViW');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (5, '2024-05-20 03:54:42.060723', '2024-05-20 03:54:42.060723', 'fEt7n3-rTOeK-snfiPHM6z:APA91bG57tZ5ctGxiYXGHhF8MfeHfKF3iarzH5HVyq1m5tYrLDswM477guCByHA-sG2dVy4fUg2Zr8ockJU4EdG_xhVH1S3ebwEdNzx1XbllSE8MwP3b__ZlCCShbx0A_0khUCIRLBv5');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (6, '2024-05-11 21:26:43.465279', '2024-05-11 21:26:43.465279', 'd8Wx2TySQbmQu8Y5JCqsOc:APA91bGEL0XPReRkt_4G-n5LkcJ0JhWzlJUmKCiOUJiXClfPTJ7wFQoOZ7at2Hh2iNDRTwXOFogZ3V1AB3lZVUWa54XcnlCNIxX-jReP9zINgtlRr-V412UnJ5EyXft057OSezFWbUlp');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (10, '2024-05-20 09:29:45.863532', '2024-05-20 09:29:45.863532', 'eZBs85tdR4-MiExIswwtMH:APA91bEVju8ROHcSwavNRscTNJdIiPEXWnAA8q7vDcT9eqRkgcxnB3VKgETkJRlxE-MbcoLejSe4KzHc0qwIfX27FTnkuCGiDtKLzUp_52WJF1s8BDXrrZWFPD8phMS4-KZONfGKBidV');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (11, '2024-05-12 19:36:19.442391', '2024-05-12 19:36:19.442391', 'e0ZA48MRTnaSLjmiElAY2y:APA91bHIUGQN8JRVoMyFyO3Dw6FCWnBQc3gYngOTEiZuDN__7T9KRWwTGfOPH8mmMv_XRG4uM5QHN8f9HV-xdWqwNCqHl895iUCXyZqLqgcgpUdZffQrwl7RXUfr6Xt1TXftz82Xmjpi');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (14, '2024-05-19 21:37:05.017730', '2024-05-19 21:37:05.017730', 'cUZJ7eAUSNiq_j7CsuT5yV:APA91bF3tVa5OK4yzOq9tigMElgrNmJiYCBJ1UcyzyqEWcPhrpA8jwHPPDnataui4kuow5H7WKcyhv3piGb1itP4DdT6qij6ibWQqnps4gNh09Uz2g3w65V1L8Gj69yW-JIt8OVX69Za');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (15, '2024-05-20 00:23:15.144352', '2024-05-20 00:23:15.144352', 'c1dat4yqTtCK47SULdx4Y9:APA91bGLmRXLTlai1oDsD1vE5J9Ie4IbFNKnHo7E-OiDYskK7MhBiJ6mE7jCxmEPlYofwX0tyzWA_AGD0Ls7BVvlXnJJB515QRI8fOqTfwmA7rsY6ifZBW3TTzA4dt4PjCUTBXmFMdHt');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (17, '2024-05-20 10:15:03.394059', '2024-05-20 10:15:03.394059', 'fRuZ9weYTSGB0IVJSQgY73:APA91bEOUQQhwINxVu_nysSWhNayFLbEW7vc39j2lQwLhrGglY-_99GBI7os41nQBHIeJR4kKe93BrN0aCb-xm92HWFVErlpznZPzu3reFptEtm3VxO7HXC497ZTUQT9I_lHxn67PVME');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (18, '2024-05-17 12:06:44.370888', '2024-05-17 12:06:44.370888', 'cZXi8zkCQVG4SVbcykRGRy:APA91bG1y5cJkRNVg0yIpOZ0rjn3LbTWpYp8QrS_QuJBbE3rk6C2g0NHTiVX1IFd4X78BG6DzUQIIgNhMyrNT1AACWvcipxdcrnHqO1eZ2obvK5pKbK2FBwuWfH72qmiQ8EKuLCN8KE1');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (19, '2024-05-20 12:05:33.697338', '2024-05-20 12:05:33.697338', 'daHYvMzuRV2627IKr6XgSi:APA91bEg8Oq3ljbUZgRU-wjIUVeDBAv9mJwADIr7eG7Sxc_ET5B-xj0iJbueboGCflEPpNDDLR27Rg8d6HqauWCOqpTluZeU5PqvLePoEGW-pgXRSz5ii1CBYzdv5pelnpZIs3eEVCRd');
INSERT INTO common.alarm_token (user_id, last_active_at, created_at, fcm_token) VALUES (23, '2024-05-20 09:16:15.842362', '2024-05-20 09:16:15.842362', 'cGB4dDQ7TzGVgiCM4po3B1:APA91bGK0srgkHTCbZIYyQTFTVv2bucr9NRyJzhjZuI3hX6Ov0X6u8dBz5mQwI6Bcm4t_HBO5N5ts46Zyew0Jb0hVzHU_pwQcyDExZKfLfXRvZZAHiRKNUYpyUnCZcicv2gWTAEkar8w');
