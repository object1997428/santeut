create table guild_user
(
    guild_user_id int auto_increment
        primary key,
    created_at    datetime(6) not null,
    deleted_at    datetime(6) null,
    guild_id      int         not null,
    is_deleted    bit         not null,
    modified_at   datetime(6) not null,
    user_id       int         not null,
    visited_at    datetime(6) not null
);

INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (3, '2024-05-07 09:43:38.058402', null, 8, false, '2024-05-07 10:48:36.018296', 1, '2024-05-07 09:43:38.058402');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (5, '2024-05-08 10:41:10.752071', null, 11, false, '2024-05-08 10:41:10.752071', 1, '2024-05-08 10:41:10.752071');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (6, '2024-05-08 10:45:06.123279', null, 11, false, '2024-05-08 10:45:06.123279', 7, '2024-05-08 10:45:06.123279');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (7, '2024-05-08 11:41:41.299112', '2024-05-08 11:42:36.292155', 11, true, '2024-05-08 11:42:36.292155', 8, '2024-05-08 11:41:41.299112');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (8, '2024-05-08 12:29:44.823026', '2024-05-08 12:33:04.632105', 11, true, '2024-05-08 12:33:04.632105', 9, '2024-05-08 12:29:44.823026');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (9, '2024-05-09 01:25:19.907150', '2024-05-14 14:35:58.015551', 11, true, '2024-05-14 14:35:58.015551', 4, '2024-05-09 01:25:19.907150');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (10, '2024-05-09 09:31:50.963637', null, 2, false, '2024-05-09 09:31:50.963637', 13, '2024-05-09 09:31:50.963637');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (11, '2024-05-13 00:37:57.553400', '2024-05-14 14:33:09.632844', 13, true, '2024-05-14 14:33:09.632837', 4, '2024-05-13 00:37:57.553400');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (13, '2024-05-13 00:45:10.297039', null, 15, false, '2024-05-13 00:45:10.297039', 4, '2024-05-13 00:45:10.297039');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (19, '2024-05-14 16:14:30.324781', null, 11, false, '2024-05-14 16:14:30.324781', 4, '2024-05-14 16:14:30.324781');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (24, '2024-05-16 09:47:44.883718', null, 25, false, '2024-05-16 09:47:44.883718', 2, '2024-05-16 09:47:44.883718');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (25, '2024-05-16 10:08:45.349667', null, 26, false, '2024-05-16 10:08:45.349676', 4, '2024-05-16 10:08:45.349639');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (27, '2024-05-16 12:41:31.984421', null, 27, false, '2024-05-16 12:41:31.984429', 4, '2024-05-16 12:41:31.984403');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (28, '2024-05-16 12:48:51.986845', null, 28, false, '2024-05-16 12:48:51.986849', 4, '2024-05-16 12:48:51.986837');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (29, '2024-05-16 12:51:46.024630', null, 29, false, '2024-05-16 12:51:46.024630', 2, '2024-05-16 12:51:46.024630');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (30, '2024-05-16 13:49:44.188083', null, 30, false, '2024-05-16 13:49:44.188083', 2, '2024-05-16 13:49:44.188083');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (31, '2024-05-16 15:09:22.319575', null, 15, false, '2024-05-16 15:09:22.319583', 14, '2024-05-16 15:09:22.319548');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (33, '2024-05-16 16:28:49.264820', null, 32, false, '2024-05-16 16:28:49.264825', 4, '2024-05-16 16:28:49.264801');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (35, '2024-05-17 10:41:27.919697', null, 33, false, '2024-05-17 10:41:27.919700', 10, '2024-05-17 10:41:27.919681');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (36, '2024-05-17 10:41:42.353718', null, 34, false, '2024-05-17 10:41:42.353725', 10, '2024-05-17 10:41:42.353711');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (37, '2024-05-17 10:41:51.502055', null, 35, false, '2024-05-17 10:41:51.502058', 10, '2024-05-17 10:41:51.502049');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (38, '2024-05-17 10:45:37.719168', null, 36, false, '2024-05-17 10:45:37.719171', 23, '2024-05-17 10:45:37.719158');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (39, '2024-05-17 10:48:15.835570', null, 37, false, '2024-05-17 10:48:15.835573', 10, '2024-05-17 10:48:15.835564');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (40, '2024-05-17 11:06:09.418626', null, 15, false, '2024-05-17 11:06:09.418626', 2, '2024-05-17 11:06:09.418626');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (41, '2024-05-17 12:07:02.157377', null, 37, false, '2024-05-17 12:07:02.157385', 18, '2024-05-17 12:07:02.157362');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (42, '2024-05-17 12:19:36.902272', null, 38, false, '2024-05-17 12:19:36.902278', 10, '2024-05-17 12:19:36.902252');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (64, '2024-05-18 17:37:26.707076', null, 37, false, '2024-05-18 17:37:26.707081', 19, '2024-05-18 17:37:26.707065');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (84, '2024-05-19 21:33:08.141068', null, 70, false, '2024-05-19 21:33:08.141071', 17, '2024-05-19 21:33:08.141060');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (85, '2024-05-20 04:21:12.516188', null, 71, false, '2024-05-20 04:21:12.516191', 3, '2024-05-20 04:21:12.516170');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (86, '2024-05-20 04:34:33.763957', null, 71, false, '2024-05-20 04:34:33.763959', 20, '2024-05-20 04:34:33.763952');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (87, '2024-05-20 06:24:42.615906', null, 36, false, '2024-05-20 06:24:42.615909', 3, '2024-05-20 06:24:42.615902');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (88, '2024-05-20 06:24:43.883574', null, 36, false, '2024-05-20 06:24:43.883577', 2, '2024-05-20 06:24:43.883569');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (89, '2024-05-20 06:53:10.851604', null, 71, false, '2024-05-20 06:53:10.851607', 2, '2024-05-20 06:53:10.851600');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (91, '2024-05-20 09:00:14.671677', null, 36, false, '2024-05-20 09:00:14.671754', 20, '2024-05-20 09:00:14.671626');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (92, '2024-05-20 09:03:24.696041', '2024-05-20 09:44:25.097097', 36, true, '2024-05-20 09:44:25.097087', 4, '2024-05-20 09:03:24.696036');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (93, '2024-05-20 09:31:18.073949', null, 71, false, '2024-05-20 09:31:18.073953', 5, '2024-05-20 09:31:18.073943');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (94, '2024-05-20 09:33:34.039248', null, 37, false, '2024-05-20 09:33:34.039251', 3, '2024-05-20 09:33:34.039243');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (95, '2024-05-20 09:46:45.619937', null, 72, false, '2024-05-20 09:46:45.619940', 4, '2024-05-20 09:46:45.619925');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (96, '2024-05-20 12:36:45.438060', null, 36, false, '2024-05-20 12:36:45.438062', 5, '2024-05-20 12:36:45.438055');
INSERT INTO guild.guild_user (guild_user_id, created_at, deleted_at, guild_id, is_deleted, modified_at, user_id, visited_at) VALUES (97, '2024-05-20 12:37:57.608307', null, 36, false, '2024-05-20 12:37:57.608309', 4, '2024-05-20 12:37:57.608301');
