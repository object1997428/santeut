create table region
(
    region_id   int        not null
        primary key,
    region_name varchar(6) not null
);

INSERT INTO guild.region (region_id, region_name) VALUES (0, '전체');
INSERT INTO guild.region (region_id, region_name) VALUES (1, '서울');
INSERT INTO guild.region (region_id, region_name) VALUES (2, '부산');
INSERT INTO guild.region (region_id, region_name) VALUES (3, '대구');
INSERT INTO guild.region (region_id, region_name) VALUES (4, '인천');
INSERT INTO guild.region (region_id, region_name) VALUES (5, '광주');
INSERT INTO guild.region (region_id, region_name) VALUES (6, '대전');
INSERT INTO guild.region (region_id, region_name) VALUES (7, '울산');
INSERT INTO guild.region (region_id, region_name) VALUES (8, '세종');
INSERT INTO guild.region (region_id, region_name) VALUES (9, '경기');
INSERT INTO guild.region (region_id, region_name) VALUES (10, '충북');
INSERT INTO guild.region (region_id, region_name) VALUES (11, '충남');
INSERT INTO guild.region (region_id, region_name) VALUES (12, '전북');
INSERT INTO guild.region (region_id, region_name) VALUES (13, '전남');
INSERT INTO guild.region (region_id, region_name) VALUES (14, '경북');
INSERT INTO guild.region (region_id, region_name) VALUES (15, '경남');
INSERT INTO guild.region (region_id, region_name) VALUES (16, '제주');
INSERT INTO guild.region (region_id, region_name) VALUES (17, '강원');
